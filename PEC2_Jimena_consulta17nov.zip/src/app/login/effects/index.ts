import { LoginEffects } from './login.effects';
import { ActivitiesEffects } from 'src/app/activities/effects/activities.effects';

export const EffectsArray: any[] = [LoginEffects, ActivitiesEffects];
